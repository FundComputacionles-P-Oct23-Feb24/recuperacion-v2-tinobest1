/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package four;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Four {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*(1*2)/7
(2*4)/14
(3*6)/21
(4*8)/28
(5*10)/35
(6*12)/42*/

        // TODO code application logic here
        
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);

         for (int i = 1; i <= 6; i++) {
            int numerador = i * 1;
            int denominador = i * 2;
            presentarValores(numerador, denominador);
        }
    }

    public static void presentarValores(int numerador, int denominador) {
        String cadena = String.format("(%d*%d) = %d", numerador, denominador,
                numerador * denominador);
        System.out.println( cadena);
    }
}