/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package one;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class One {

    /**
     * @param args the command line arguments
     */
    // TODO code application logic here
    public static double totalPagar(double librasCamaron, double librasBacalao) {
        double precioCamaron = 1.1;
        double precioBacalao = 1.20;

        return (librasCamaron * precioCamaron) + (librasBacalao * precioBacalao);
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);
        String nombre;
        double librasCamaron;
        double librasBacalao;
        String cadena;
        String terminar;
        double totalPagar;

        do{

            System.out.println("Ingrese el nombre del pescador:");
            nombre = entrada.nextLine();
            System.out.println("Ingrese el numero de libras de camaron vendidas:");
            librasCamaron = entrada.nextDouble();
            System.out.println("Ingrese el numero de libras de bacalao vendidas:");
            librasBacalao = entrada.nextDouble();
            entrada.nextLine();

            totalPagar = totalPagar(librasCamaron, librasBacalao);

            cadena = String.format("Pescaderia de la ciudad:\n"
                    + "Pescador: %s\n"
                    + "Libras de camaron: %.2f - costo: %.2f\n"
                    + "Libras de bacalao: %.2f - costo: %.2f\n"
                    + "Total a pagar al pescador: %.2f\n", nombre,
                    librasCamaron, librasCamaron * 1.1,
                    librasBacalao, librasBacalao * 1.20, totalPagar);

            System.out.println(cadena);
            System.out.println("Si desea salir ingrese algo diferente de: (y)");
            terminar = entrada.nextLine();

        }while(terminar.equals("y"));
        
        
        

    }
}
